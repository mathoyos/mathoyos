Replication Package for “Tariffs and Growth: Evidence of Heterogeneity by Comparative Advantage”
Journal of Comparative Economics

Overview
This archive contains all data and code necessary to replicate the empirical results and figures presented in the paper. The package is organized to allow users to reproduce the analysis starting from the raw data sources through the final dataset, and then to the estimation and figures reported in the manuscript.

Contents

1. Data Construction
	•	database_creation.do Stata do-file that assembles the raw data files into the final dataset used for analysis (database.dta). Running this script sequentially will:
	◦	Load all raw input datasets listed below.
	◦	Clean and harmonize variables.
	◦	Merge them into a single balanced dataset.
	◦	Output the file database.dta.
	•	Raw Data Files (all in .dta format):
	◦	exprind.dta – Terms of trade data.
	◦	furcerietal.dta – Tariff data from Furceri et al.
	◦	imfweoforec.dta – IMF World Economic Outlook forecasts.
	◦	MATR.dta – MATR dataset on tariffs.
	◦	mpd2020.dta – Maddison Project Database (2020 release).
	◦	polityV.dta – Polity V index of political regimes.
	◦	pwt10.dta – Penn World Tables, version 10.
	◦	regionsfromacem.dta – Regional classifications.
	◦	services_wdi.dta – World Development Indicators, services variables.
	◦	trade_indices.dta – Data on manufacturing exports, based on Comtrade data.
	◦	wdidata2022.dta – World Development Indicators (downloaded in 2022).

2. Final Dataset
	•	database.dta Final dataset created by running database_creation.do. This is the dataset used in all analyses of the paper.

3. Analysis
	•	localproj_JCE.do Stata do-file that takes database.dta as input and replicates all the figures presented in the paper. 

Instructions for Replication

	1	Place all files in the same working directory.
	2	Open Stata and run database_creation.do.
	◦	This will generate the file database.dta.
	3	Next, run localproj_JCE.do.
	◦	This will use database.dta to produce all tables and figures.

The replication should complete without modification if run in this order.

Notes
	•	All raw data are publicly available and documented in the main text of the paper.
	•	If newer versions of the raw datasets are available, small discrepancies may arise. For full replication, please use the provided versions in this archive.
	•	Software: All scripts were written and tested in Stata 17.
