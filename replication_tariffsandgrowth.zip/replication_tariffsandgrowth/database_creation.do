

********************************************************************************
*					  Tariff Changes and Economic Growth                       *   
* 								  Mateo Hoyos	                               *
* 							  Database creation	                               *
* 								  JUL 2022		   		          	       *
********************************************************************************

********************************************************************************
                  * 		      A. Database                *                   
********************************************************************************

cd "/Users/mhoyoslopez/Dropbox/Doctorado/PhD Dissertation/Dissertation/Empirical - Tariffs and Growth/data/"

* The fundamental data comes from PWT 10.0


use pwt10, clear
keep countrycode country year rgdpo emp pop rgdpna rnna rtfpna hc
gen gdppc= rgdpna/pop
gen gdppcppp= rgdpo/pop
label var gdppc "GDP per capita (2017 national prices constant dollars)"
label var gdppcppp "GDP per capita PPP (2017 US dollars)"
keep if year>1959
save database, replace

* Adding WDI data

use wdidata2022, clear
keep if year<2020
replace countrycode="KOS" if countrycode=="XKX"
save temp, replace

use database, clear
merge 1:1 countrycode year using temp
drop country _merge
order countrycode year gdppc gdppcppp gdppcwdi rgdpna rgdpo
save database, replace

merge 1:1 countrycode year using services_wdi
drop _merge
save database, replace

* Adding the tariff data from Furceri et al. (and reer and tb for covariates robustness)

use furcerietal, clear
collapse (min) ifscode, by(wdicode)
drop if wdicode==""
save temp, replace
use furcerietal, clear
drop _merge
drop wdicode
merge m:1 ifscode using temp
replace wdicode="PRI" if ifscode==359
replace wdicode="MAC" if ifscode==546
replace wdicode="SOM" if ifscode==726
replace wdicode="ROU" if wdicode=="ROM"
keep wdicode year tariff country tb reer gini_net_50 ngdp_r
keep if year>1959
rename country countryname
rename wdicode countrycode
bys countrycode: egen meantar=mean(tariff)
drop if meantar==.
drop meantar

save temp, replace

use database, clear
merge 1:1 countrycode year using temp
drop _merge // no tariff data for: Aruba, Anguilla,  Bermuda, Curacao, Cayman Islands, Maldives, Montserrat, State of Palestine, Sint Maarten, Turks and Caicos Islands, Tajikistan, British Virgin Islands
drop countryname
save database, replace

* Adding non-tariff barriers

use database, clear
merge 1:1 year countrycode using MATR
drop _merge
keep if year<2020
keep if year>1959
save database, replace


* Adding manufacturing exports data

use database, clear
merge 1:1 countrycode year using trade_indices
drop if _merge==2
drop _merge
encode countrycode, gen(cocode)
save database, replace

use database, clear
merge 1:1 countrycode year using temp
drop if _merge==2
drop _merge
save database, replace

* Adding Polity data

use polityV, clear
drop if year>2019
drop if year<1960

drop if countrycode=="SDN"
replace countrycode="AGO" if countrycode=="ANG"
replace countrycode="AUT" if countrycode=="AUS"
replace countrycode="BDI" if countrycode=="BUI"
replace countrycode="BFA" if countrycode=="BFO"
replace countrycode="BGD" if countrycode=="BNG"
replace countrycode="BGR" if countrycode=="BUL"
replace countrycode="BHR" if countrycode=="BAH"
replace countrycode="AUS" if countrycode=="AUL"
replace countrycode="BTN" if countrycode=="BHU"
replace countrycode="BWA" if countrycode=="BOT"
replace countrycode="CAF" if countrycode=="CEN"
replace countrycode="CHE" if countrycode=="SWZ"
replace countrycode="CIV" if countrycode=="IVO"
replace countrycode="CMR" if countrycode=="CAO"
replace countrycode="COG" if countrycode=="CON"
replace countrycode="COD" if countrycode=="ZAI"
replace countrycode="CPV" if countrycode=="CAP"
replace countrycode="CRI" if countrycode=="COS"
replace countrycode="CZE" if countrycode=="CZR"
replace countrycode="SVK" if countrycode=="SLO"
replace countrycode="DEU" if countrycode=="GMY"
replace countrycode="DNK" if countrycode=="DEN"
replace countrycode="DZA" if countrycode=="ALG"
replace countrycode="ESP" if countrycode=="SPN"
replace countrycode="ETH" if countrycode=="ETI"
replace countrycode="FRA" if countrycode=="FRN"
replace countrycode="GBR" if countrycode=="UKG"
replace countrycode="GEO" if countrycode=="GRG"
replace countrycode="GIN" if countrycode=="GUI"
replace countrycode="GMB" if countrycode=="GAM"
replace countrycode="GTM" if countrycode=="GUA"
replace countrycode="HND" if countrycode=="HON"
replace countrycode="HRV" if countrycode=="CRO"
replace countrycode="HTI" if countrycode=="HAI"
replace countrycode="IDN" if countrycode=="INS"
replace countrycode="IRL" if countrycode=="IRE"
replace countrycode="KAZ" if countrycode=="KZK"
replace countrycode="KGZ" if countrycode=="KYR"
replace countrycode="KHM" if countrycode=="CAM"
replace countrycode="KOR" if countrycode=="ROK"
replace countrycode="KWT" if countrycode=="KUW"
replace countrycode="LBN" if countrycode=="LEB"
replace countrycode="LBY" if countrycode=="LIB"
replace countrycode="LKA" if countrycode=="SRI"
replace countrycode="LTU" if countrycode=="LIT"
replace countrycode="LVA" if countrycode=="LAT"
replace countrycode="MAR" if countrycode=="MOR"
replace countrycode="MDA" if countrycode=="MLD"
replace countrycode="MDG" if countrycode=="MAG"
replace countrycode="MKD" if countrycode=="MAC"
replace countrycode="MMR" if countrycode=="MYA"
replace countrycode="MNE" if countrycode=="MNT"
replace countrycode="MNG" if countrycode=="MON"
replace countrycode="MOZ" if countrycode=="MZM"
replace countrycode="MRT" if countrycode=="MAA"
replace countrycode="MUS" if countrycode=="MAS"
replace countrycode="MWI" if countrycode=="MAW"
replace countrycode="MYS" if countrycode=="MAL"
replace countrycode="NER" if countrycode=="NIR"
replace countrycode="NGA" if countrycode=="NIG"
replace countrycode="NLD" if countrycode=="NTH"
replace countrycode="NPL" if countrycode=="NEP"
replace countrycode="NZL" if countrycode=="NEW"
replace countrycode="OMN" if countrycode=="OMA"
replace countrycode="PHL" if countrycode=="PHI"
replace countrycode="PRT" if countrycode=="POR"
replace countrycode="PRY" if countrycode=="PAR"
replace countrycode="ROU" if countrycode=="RUM"
replace countrycode="SDN" if countrycode=="SUD"
replace countrycode="SGP" if countrycode=="SIN"
replace countrycode="SLE" if countrycode=="SIE"
replace countrycode="SVN" if countrycode=="SLV"
replace countrycode="SLV" if countrycode=="SAL"
replace countrycode="SWE" if countrycode=="SWD"
replace countrycode="TCD" if countrycode=="CHA"
replace countrycode="TGO" if countrycode=="TOG"
replace countrycode="THA" if countrycode=="THI"
replace countrycode="TTO" if countrycode=="TRI"
replace countrycode="TWN" if countrycode=="TAW"
replace countrycode="TZA" if countrycode=="TAZ"
replace countrycode="URY" if countrycode=="URU"
replace countrycode="VNM" if countrycode=="VIE"
replace countrycode="ZAF" if countrycode=="SAF"
replace countrycode="ZMB" if countrycode=="ZAM"
replace countrycode="ZWE" if countrycode=="ZIM"
replace countrycode="SWZ" if countrycode=="SWA"
replace countrycode="PAK" if countrycode=="PKS"
replace countrycode="ARE" if countrycode=="UAE"
replace countrycode="RUS" if countrycode=="USR"

save temp, replace

use database, clear
merge 1:1 countrycode year using temp
drop if _merge==2
drop _merge
rename polity2 polity
label var polity "Polity (institutional) score from Polity V"
save database, replace

* Adding GDP pc from Maddison

use mpd2020, replace
rename gdppc gdpmad
keep countrycode year gdpmad
keep if year>1959
keep if year<2020
save temp, replace

use database, clear
merge 1:1 countrycode year using temp
drop if _merge==2
drop _merge
order countryname countrycode year gdppc gdppcppp gdppcwdi gdpmad tariff polity manexp rcamanexp exports invgdp imports lifexp childmort trade
save database, replace

* Adding growth forecasts


clear all
use imfweoforec
drop f*
gen yearf=year+1

encode country, g(cocode)
xtset cocode yearf, yearly

foreach x in 1990 1991 1992 1993 1994 1995 1996 1997 1998 1999 2000 2001 2002 2003 2004 2005 2006 2007 2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019  {
	gen grochfor`x'=s`x'ngdp_rpch-l.s`x'ngdp_rpch
	
}

foreach x in 1990 1991 1992 1993 1994 1995 1996 1997 1998 1999 2000 2001 2002 2003 2004 2005 2006 2007 2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019{
	replace grochfor`x'=. if yearf!=`x'
}

gen grochfor=.
foreach x in 1990 1991 1992 1993 1994 1995 1996 1997 1998 1999 2000 2001 2002 2003 2004 2005 2006 2007 2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019{
	replace grochfor=grochfor`x' if yearf==`x'
}

gen grofor=.
foreach x in 1990 1991 1992 1993 1994 1995 1996 1997 1998 1999 2000 2001 2002 2003 2004 2005 2006 2007 2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019{
	replace grofor=s`x'ngdp_rpch if yearf==`x'
}

keep country isoalpha_3code yearf grofor grochfor
order country isoalpha_3code yearf grofor grochfor
rename isoalpha_3code countrycode
rename yearf year
keep if countrycode!=""
label var grofor "Growth forecast for the year made in the previous year"
label var grochfor "Change in the growth forecast made in the previous year respect the forecast two years before"
drop if year>2019
drop if year<1990
save temp, replace


use database, clear
merge 1:1 countrycode year using temp
drop if _merge==2
drop _merge
save database, replace


* Adding Terms of Trade

use database, clear
merge 1:1 countrycode year using exprind
drop if _merge==2
drop _merge
save database, replace


* Adding regions and creating the dependent and independent variable

clear all
use database
xtset cocode year, yearly

gen lgdp=ln(gdppc)
replace lgdp=100*lgdp

gen xvar=d.tariff
gen lxvar=l.d.tariff

gen g=lgdp-l.lgdp

gen newcl=cocode
tab year, gen(yy)
tab countrycode, gen(cc)


gen lgdpmad=ln(gdpmad)
xtile quar = gdpmad if year==1960,n(5)
bys cocode: egen quart=max(quar)
egen interfull = group(quart year)


replace manexp=manexp*100

* Adding regions

merge m:1 countrycode using regionsfromacem
drop if _merge==2
drop _merge
encode regioncode, gen(regcode)
egen rryy = group(regcode year)


sort cocode year
xtset cocode year, yearly
gen lavman=(l.manexp+l2.manexp+l3.manexp+l4.manexp+l5.manexp)/5
gen intman=xvar*lavman

save database, replace


