


********************************************************************************
*					  		  Tariffs and Growth      	   	                   *   
* 								  Mateo Hoyos	                               *
* 							  Database creation	                               *
* 								  Aug 2025		   		          	           *
********************************************************************************

********************************************************************************	
****** Empirical strategy ******
********************************************************************************
	
* 1. General trends

cd "/Users/mhoyoslopez/Dropbox/Doctorado/PhD Dissertation/Dissertation/Empirical - Tariffs and Growth/data/"
clear all
set more off
use database
xtset cocode year, yearly

gen y1=l16.lgdp-l.lgdp
gen y2=l15.lgdp-l.lgdp
gen y3=l14.lgdp-l.lgdp
gen y4=l13.lgdp-l.lgdp
gen y5=l12.lgdp-l.lgdp
gen y6=l11.lgdp-l.lgdp
gen y7=l10.lgdp-l.lgdp
gen y8=l9.lgdp-l.lgdp
gen y9=l8.lgdp-l.lgdp
gen y10=l7.lgdp-l.lgdp
gen y11=l6.lgdp-l.lgdp
gen y12=l5.lgdp-l.lgdp
gen y13=l4.lgdp-l.lgdp
gen y14=l3.lgdp-l.lgdp
gen y15=l2.lgdp-l.lgdp

gen y16=l.lgdp-l.lgdp

gen y17=lgdp-l.lgdp

gen y18=f1.lgdp-l.lgdp
gen y19=f2.lgdp-l.lgdp
gen y20=f3.lgdp-l.lgdp
gen y21=f4.lgdp-l.lgdp
gen y22=f5.lgdp-l.lgdp
gen y23=f6.lgdp-l.lgdp
gen y24=f7.lgdp-l.lgdp
gen y25=f8.lgdp-l.lgdp
gen y26=f9.lgdp-l.lgdp
gen y27=f10.lgdp-l.lgdp
gen y28=f11.lgdp-l.lgdp
gen y29=f12.lgdp-l.lgdp
gen y30=f13.lgdp-l.lgdp
gen y31=f14.lgdp-l.lgdp
gen y32=f15.lgdp-l.lgdp
gen y33=f16.lgdp-l.lgdp
gen y34=f17.lgdp-l.lgdp
gen y35=f18.lgdp-l.lgdp
gen y36=f19.lgdp-l.lgdp

gen Years = _n-1 - 15 if _n <= 36
gen zero = 0 if _n <= 36

scalar sig = 0.1
	
generate blow =.
generate selow =.

sum xvar, d
local sdta=r(sd)

forvalues nvar = 1/15 {
reghdfe y`nvar' xvar, cl(cocode) absorb(year)
nlcom (low: -1*_b[xvar]*`sdta'), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

}

replace blow  = 0 if _n == 16
replace selow = 0 if _n == 16


forvalues nvar = 17/36 {
reghdfe y`nvar' xvar, cl(cocode) absorb(year)
nlcom (low: -1*_b[xvar]*`sdta'), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

}

	gen uplow = blow + invnormal(1-sig/2)*selow if _n <= 36
	gen dnlow = blow - invnormal(1-sig/2)*selow if _n <= 36

	
twoway (line uplow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnlow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line blow Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "general_wolags.eps", replace



* 2. Pre-trends to tariff changes

foreach i in 1 2 4 8 {
cd "/Users/mhoyoslopez/Dropbox/Doctorado/PhD Dissertation/Dissertation/Empirical - Tariffs and Growth/data/"
clear all
use database
xtset cocode year, yearly

gen y1=l16.lgdp-l.lgdp
gen y2=l15.lgdp-l.lgdp
gen y3=l14.lgdp-l.lgdp
gen y4=l13.lgdp-l.lgdp
gen y5=l12.lgdp-l.lgdp
gen y6=l11.lgdp-l.lgdp
gen y7=l10.lgdp-l.lgdp
gen y8=l9.lgdp-l.lgdp
gen y9=l8.lgdp-l.lgdp
gen y10=l7.lgdp-l.lgdp
gen y11=l6.lgdp-l.lgdp
gen y12=l5.lgdp-l.lgdp
gen y13=l4.lgdp-l.lgdp
gen y14=l3.lgdp-l.lgdp
gen y15=l2.lgdp-l.lgdp

gen y16=l.lgdp-l.lgdp

gen y17=lgdp-l.lgdp

gen y18=f1.lgdp-l.lgdp
gen y19=f2.lgdp-l.lgdp
gen y20=f3.lgdp-l.lgdp
gen y21=f4.lgdp-l.lgdp
gen y22=f5.lgdp-l.lgdp
gen y23=f6.lgdp-l.lgdp
gen y24=f7.lgdp-l.lgdp
gen y25=f8.lgdp-l.lgdp
gen y26=f9.lgdp-l.lgdp
gen y27=f10.lgdp-l.lgdp
gen y28=f11.lgdp-l.lgdp
gen y29=f12.lgdp-l.lgdp
gen y30=f13.lgdp-l.lgdp
gen y31=f14.lgdp-l.lgdp
gen y32=f15.lgdp-l.lgdp
gen y33=f16.lgdp-l.lgdp
gen y34=f17.lgdp-l.lgdp
gen y35=f18.lgdp-l.lgdp
gen y36=f19.lgdp-l.lgdp

gen Years = _n-1 - 15 if _n <= 36
gen zero = 0 if _n <= 36

scalar sig = 0.1
	
generate blow =.
generate selow =.

sum xvar, d
local sdta=r(sd)

forvalues nvar = 1/15 {
reghdfe y`nvar' l(1/`i').g xvar, cl(cocode) absorb(year)
nlcom (low: -1*_b[xvar]*`sdta'), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

}

replace blow  = 0 if _n == 16
replace selow = 0 if _n == 16


forvalues nvar = 17/36 {
reghdfe y`nvar' l(1/`i').g xvar, cl(cocode) absorb(year)
nlcom (low: -1*_b[xvar]*`sdta'), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

}

	gen uplow = blow + invnormal(1-sig/2)*selow if _n <= 36
	gen dnlow = blow - invnormal(1-sig/2)*selow if _n <= 36

	
twoway (line uplow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnlow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line blow Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "general_`i'lags.eps", replace
	
}
*


********************************************************************************	
****** Results ******
********************************************************************************
	

	
* 1. Baseline results
	

cd "/Users/mhoyoslopez/Dropbox/Doctorado/PhD Dissertation/Dissertation/Empirical - Tariffs and Growth/data/"
clear all
use database
xtset cocode year, yearly

gen y1=l16.lgdp-l.lgdp
gen y2=l15.lgdp-l.lgdp
gen y3=l14.lgdp-l.lgdp
gen y4=l13.lgdp-l.lgdp
gen y5=l12.lgdp-l.lgdp
gen y6=l11.lgdp-l.lgdp
gen y7=l10.lgdp-l.lgdp
gen y8=l9.lgdp-l.lgdp
gen y9=l8.lgdp-l.lgdp
gen y10=l7.lgdp-l.lgdp
gen y11=l6.lgdp-l.lgdp
gen y12=l5.lgdp-l.lgdp
gen y13=l4.lgdp-l.lgdp
gen y14=l3.lgdp-l.lgdp
gen y15=l2.lgdp-l.lgdp

gen y16=l.lgdp-l.lgdp

gen y17=lgdp-l.lgdp

gen y18=f1.lgdp-l.lgdp
gen y19=f2.lgdp-l.lgdp
gen y20=f3.lgdp-l.lgdp
gen y21=f4.lgdp-l.lgdp
gen y22=f5.lgdp-l.lgdp
gen y23=f6.lgdp-l.lgdp
gen y24=f7.lgdp-l.lgdp
gen y25=f8.lgdp-l.lgdp
gen y26=f9.lgdp-l.lgdp
gen y27=f10.lgdp-l.lgdp
gen y28=f11.lgdp-l.lgdp
gen y29=f12.lgdp-l.lgdp
gen y30=f13.lgdp-l.lgdp
gen y31=f14.lgdp-l.lgdp
gen y32=f15.lgdp-l.lgdp
gen y33=f16.lgdp-l.lgdp
gen y34=f17.lgdp-l.lgdp
gen y35=f18.lgdp-l.lgdp
gen y36=f19.lgdp-l.lgdp

gen Years = _n-1 - 15 if _n <= 36
gen zero = 0 if _n <= 36

scalar sig = 0.1
	
generate blow =.
generate selow =.

generate bhigh =.
generate sehigh =.

sum manexp, d
local lowman=r(p10)
local highman=r(p90)

sum xvar, d
local sdta=r(sd)

forvalues nvar = 1/15 {
reghdfe y`nvar' l(1/8).g xvar lavman intman, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

replace blow  = 0 if _n == 16
replace selow = 0 if _n == 16

replace bhigh  = 0 if _n == 16
replace sehigh = 0 if _n == 16

forvalues nvar = 17/36 {
reghdfe y`nvar' l(1/8).g xvar lavman intman, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

	gen uplow = blow + invnormal(1-sig/2)*selow if _n <= 36
	gen dnlow = blow - invnormal(1-sig/2)*selow if _n <= 36
	
	gen uphigh = bhigh + invnormal(1-sig/2)*sehigh if _n <= 36
	gen dnhigh = bhigh - invnormal(1-sig/2)*sehigh if _n <= 36
	
	
twoway (line uplow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnlow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line blow Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "low.eps",   replace
	
twoway (line uphigh Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnhigh  Years,  lcolor(gs12) lpattern(dash)) ///
	(line bhigh Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "high.eps",   replace

	
	
* 2. Baseline results with fixed effects
	

cd "/Users/mhoyoslopez/Dropbox/Doctorado/PhD Dissertation/Dissertation/Empirical - Tariffs and Growth/data/"
clear all
use database
xtset cocode year, yearly

gen y1=l16.lgdp-l.lgdp
gen y2=l15.lgdp-l.lgdp
gen y3=l14.lgdp-l.lgdp
gen y4=l13.lgdp-l.lgdp
gen y5=l12.lgdp-l.lgdp
gen y6=l11.lgdp-l.lgdp
gen y7=l10.lgdp-l.lgdp
gen y8=l9.lgdp-l.lgdp
gen y9=l8.lgdp-l.lgdp
gen y10=l7.lgdp-l.lgdp
gen y11=l6.lgdp-l.lgdp
gen y12=l5.lgdp-l.lgdp
gen y13=l4.lgdp-l.lgdp
gen y14=l3.lgdp-l.lgdp
gen y15=l2.lgdp-l.lgdp

gen y16=l.lgdp-l.lgdp

gen y17=lgdp-l.lgdp

gen y18=f1.lgdp-l.lgdp
gen y19=f2.lgdp-l.lgdp
gen y20=f3.lgdp-l.lgdp
gen y21=f4.lgdp-l.lgdp
gen y22=f5.lgdp-l.lgdp
gen y23=f6.lgdp-l.lgdp
gen y24=f7.lgdp-l.lgdp
gen y25=f8.lgdp-l.lgdp
gen y26=f9.lgdp-l.lgdp
gen y27=f10.lgdp-l.lgdp
gen y28=f11.lgdp-l.lgdp
gen y29=f12.lgdp-l.lgdp
gen y30=f13.lgdp-l.lgdp
gen y31=f14.lgdp-l.lgdp
gen y32=f15.lgdp-l.lgdp
gen y33=f16.lgdp-l.lgdp
gen y34=f17.lgdp-l.lgdp
gen y35=f18.lgdp-l.lgdp
gen y36=f19.lgdp-l.lgdp

gen Years = _n-1 - 15 if _n <= 36
gen zero = 0 if _n <= 36

scalar sig = 0.1
	
generate blow =.
generate selow =.

generate bhigh =.
generate sehigh =.

sum manexp, d
local lowman=r(p10)
local highman=r(p90)

sum xvar, d
local sdta=r(sd)

forvalues nvar = 1/15 {
reghdfe y`nvar' l(1/8).g xvar lavman intman, absorb(year cocode) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

replace blow  = 0 if _n == 16
replace selow = 0 if _n == 16

replace bhigh  = 0 if _n == 16
replace sehigh = 0 if _n == 16

forvalues nvar = 17/36 {
reghdfe y`nvar' l(1/8).g xvar lavman intman, absorb(year cocode) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

	gen uplow = blow + invnormal(1-sig/2)*selow if _n <= 36
	gen dnlow = blow - invnormal(1-sig/2)*selow if _n <= 36
	
	gen uphigh = bhigh + invnormal(1-sig/2)*sehigh if _n <= 36
	gen dnhigh = bhigh - invnormal(1-sig/2)*sehigh if _n <= 36
	
	
twoway (line uplow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnlow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line blow Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "low_cocode.eps",   replace
	
twoway (line uphigh Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnhigh  Years,  lcolor(gs12) lpattern(dash)) ///
	(line bhigh Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "high_cocode.eps",   replace



* 3. Estimates with dummies instead of linear relationship ***

clear all
use database

xtset cocode year, yearly

gen y1=l16.lgdp-l.lgdp
gen y2=l15.lgdp-l.lgdp
gen y3=l14.lgdp-l.lgdp
gen y4=l13.lgdp-l.lgdp
gen y5=l12.lgdp-l.lgdp
gen y6=l11.lgdp-l.lgdp
gen y7=l10.lgdp-l.lgdp
gen y8=l9.lgdp-l.lgdp
gen y9=l8.lgdp-l.lgdp
gen y10=l7.lgdp-l.lgdp
gen y11=l6.lgdp-l.lgdp
gen y12=l5.lgdp-l.lgdp
gen y13=l4.lgdp-l.lgdp
gen y14=l3.lgdp-l.lgdp
gen y15=l2.lgdp-l.lgdp

gen y16=l.lgdp-l.lgdp

gen y17=lgdp-l.lgdp

gen y18=f1.lgdp-l.lgdp
gen y19=f2.lgdp-l.lgdp
gen y20=f3.lgdp-l.lgdp
gen y21=f4.lgdp-l.lgdp
gen y22=f5.lgdp-l.lgdp
gen y23=f6.lgdp-l.lgdp
gen y24=f7.lgdp-l.lgdp
gen y25=f8.lgdp-l.lgdp
gen y26=f9.lgdp-l.lgdp
gen y27=f10.lgdp-l.lgdp
gen y28=f11.lgdp-l.lgdp
gen y29=f12.lgdp-l.lgdp
gen y30=f13.lgdp-l.lgdp
gen y31=f14.lgdp-l.lgdp
gen y32=f15.lgdp-l.lgdp
gen y33=f16.lgdp-l.lgdp
gen y34=f17.lgdp-l.lgdp
gen y35=f18.lgdp-l.lgdp
gen y36=f19.lgdp-l.lgdp

gen Years = _n-1 - 15 if _n <= 36
gen zero = 0 if _n <= 36

xtile quint = lavman,n(3)

tab quint, gen(qu)

foreach x in 1 2 3 {
	
	gen intes`x'=qu`x'*xvar
}

	scalar sig = 0.1	 // specify significance level

	generate blow2 =.
	generate selow2 =.
	
	generate blow1 =.
	generate selow1 =.
	
	generate bhigh1 =.
	generate sehigh1 =.
	
	generate bhigh2 =.
	generate sehigh2 =.
	
sum xvar, d
local sdta=r(sd)

forvalues nvar = 1/15 {

reghdfe y`nvar' l(1/8).g xvar qu1 qu2 qu3 intes1 intes2 intes3, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (low1:-1*`sdta'*(_b[xvar]+_b[intes1])) (high1:-1*`sdta'*(_b[xvar]+_b[intes3])), post

replace blow1  = _b[low1] if _n == `nvar'
replace selow1 = _se[low1] if _n == `nvar'

replace bhigh1  = _b[high1] if _n == `nvar'
replace sehigh1 = _se[high1] if _n == `nvar'


}

replace blow1  = 0 if _n == 16
replace selow1= 0 if _n == 16

replace bhigh1  = 0 if _n == 16
replace sehigh1 = 0 if _n == 16



forvalues nvar = 17/36 {
reghdfe y`nvar' l(1/8).g xvar qu1 qu2 qu3 intes1 intes2 intes3, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (low1:-1*`sdta'*(_b[xvar]+_b[intes1])) (high1:-1*`sdta'*(_b[xvar]+_b[intes3])), post

replace blow1  = _b[low1] if _n == `nvar'
replace selow1 = _se[low1] if _n == `nvar'

replace bhigh1  = _b[high1] if _n == `nvar'
replace sehigh1 = _se[high1] if _n == `nvar'
}


	gen uplow1 = blow1 + invnormal(1-sig/2)*selow1 if _n <= 36
	gen dnlow1 = blow1 - invnormal(1-sig/2)*selow1 if _n <= 36
	
	gen uphigh1 = bhigh1 + invnormal(1-sig/2)*sehigh1 if _n <= 36
	gen dnhigh1 = bhigh1 - invnormal(1-sig/2)*sehigh1 if _n <= 36

	
twoway (line uplow1  Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnlow1  Years,  lcolor(gs12) lpattern(dash)) ///
	(line blow1 Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "lownon1.eps",   replace
	
twoway (line uphigh1 Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnhigh1  Years,  lcolor(gs12) lpattern(dash)) ///
	(line bhigh1 Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "highnon1.eps",   replace

	
	
* 4. Including endogenous trade policy variables

cd "/Users/mhoyoslopez/Dropbox/Doctorado/PhD Dissertation/Dissertation/Empirical - Tariffs and Growth/data/"
clear all
use database
xtset cocode year, yearly

gen y1=l16.lgdp-l.lgdp
gen y2=l15.lgdp-l.lgdp
gen y3=l14.lgdp-l.lgdp
gen y4=l13.lgdp-l.lgdp
gen y5=l12.lgdp-l.lgdp
gen y6=l11.lgdp-l.lgdp
gen y7=l10.lgdp-l.lgdp
gen y8=l9.lgdp-l.lgdp
gen y9=l8.lgdp-l.lgdp
gen y10=l7.lgdp-l.lgdp
gen y11=l6.lgdp-l.lgdp
gen y12=l5.lgdp-l.lgdp
gen y13=l4.lgdp-l.lgdp
gen y14=l3.lgdp-l.lgdp
gen y15=l2.lgdp-l.lgdp

gen y16=l.lgdp-l.lgdp

gen y17=lgdp-l.lgdp

gen y18=f1.lgdp-l.lgdp
gen y19=f2.lgdp-l.lgdp
gen y20=f3.lgdp-l.lgdp
gen y21=f4.lgdp-l.lgdp
gen y22=f5.lgdp-l.lgdp
gen y23=f6.lgdp-l.lgdp
gen y24=f7.lgdp-l.lgdp
gen y25=f8.lgdp-l.lgdp
gen y26=f9.lgdp-l.lgdp
gen y27=f10.lgdp-l.lgdp
gen y28=f11.lgdp-l.lgdp
gen y29=f12.lgdp-l.lgdp
gen y30=f13.lgdp-l.lgdp
gen y31=f14.lgdp-l.lgdp
gen y32=f15.lgdp-l.lgdp
gen y33=f16.lgdp-l.lgdp
gen y34=f17.lgdp-l.lgdp
gen y35=f18.lgdp-l.lgdp
gen y36=f19.lgdp-l.lgdp

gen dpolity=d.polity
gen dsch=d.hc
gen dtrade=d.trade
replace pop=ln(pop)
gen dpop=d.pop
gen dinv=d.invgdp
gen dreer=d.reer
gen dtot=d.exprind
gen dgfor=d.grochfor
gen dgini=d.gini
gen dimp=d.imports
gen dmatr=d.matr_nt

gen Years = _n-1 - 15 if _n <= 36
gen zero = 0 if _n <= 36

scalar sig = 0.1
	
generate blow =.
generate selow =.

generate bhigh =.
generate sehigh =.

sum manexp, d
local lowman=r(p10)
local highman=r(p90)

sum xvar, d
local sdta=r(sd)

forvalues nvar = 1/15 {
reghdfe y`nvar' l(1/8).g xvar lavman intman d.grofor l(1/4).dgini l(1/4).dimp l(1/4).dpolity  l(1/4).dreer, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

replace blow  = 0 if _n == 16
replace selow = 0 if _n == 16

replace bhigh  = 0 if _n == 16
replace sehigh = 0 if _n == 16

forvalues nvar = 17/36 {
reghdfe y`nvar' l(1/8).g xvar lavman intman d.grofor l(1/4).dgini l(1/4).dimp l(1/4).dpolity  l(1/4).dreer, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

	gen uplow = blow + invnormal(1-sig/2)*selow if _n <= 36
	gen dnlow = blow - invnormal(1-sig/2)*selow if _n <= 36
	
	gen uphigh = bhigh + invnormal(1-sig/2)*sehigh if _n <= 36
	gen dnhigh = bhigh - invnormal(1-sig/2)*sehigh if _n <= 36
	
	

twoway (line uphigh Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnhigh  Years,  lcolor(gs12) lpattern(dash)) ///
	(line bhigh Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "high_end.eps",   replace

	
twoway (line uplow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnlow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line blow Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "low_end.eps",  replace
	
	
********************************************************************************	
****** Robustness ******
********************************************************************************
	


* 7. All control variables

cd "/Users/mhoyoslopez/Dropbox/Doctorado/PhD Dissertation/Dissertation/Empirical - Tariffs and Growth/data/"
clear all
use database
xtset cocode year, yearly

gen y1=l16.lgdp-l.lgdp
gen y2=l15.lgdp-l.lgdp
gen y3=l14.lgdp-l.lgdp
gen y4=l13.lgdp-l.lgdp
gen y5=l12.lgdp-l.lgdp
gen y6=l11.lgdp-l.lgdp
gen y7=l10.lgdp-l.lgdp
gen y8=l9.lgdp-l.lgdp
gen y9=l8.lgdp-l.lgdp
gen y10=l7.lgdp-l.lgdp
gen y11=l6.lgdp-l.lgdp
gen y12=l5.lgdp-l.lgdp
gen y13=l4.lgdp-l.lgdp
gen y14=l3.lgdp-l.lgdp
gen y15=l2.lgdp-l.lgdp

gen y16=l.lgdp-l.lgdp

gen y17=lgdp-l.lgdp

gen y18=f1.lgdp-l.lgdp
gen y19=f2.lgdp-l.lgdp
gen y20=f3.lgdp-l.lgdp
gen y21=f4.lgdp-l.lgdp
gen y22=f5.lgdp-l.lgdp
gen y23=f6.lgdp-l.lgdp
gen y24=f7.lgdp-l.lgdp
gen y25=f8.lgdp-l.lgdp
gen y26=f9.lgdp-l.lgdp
gen y27=f10.lgdp-l.lgdp
gen y28=f11.lgdp-l.lgdp
gen y29=f12.lgdp-l.lgdp
gen y30=f13.lgdp-l.lgdp
gen y31=f14.lgdp-l.lgdp
gen y32=f15.lgdp-l.lgdp
gen y33=f16.lgdp-l.lgdp
gen y34=f17.lgdp-l.lgdp
gen y35=f18.lgdp-l.lgdp
gen y36=f19.lgdp-l.lgdp

gen dpolity=d.polity
gen dsch=d.hc
gen dtrade=d.trade
replace pop=ln(pop)
gen dpop=d.pop
gen dinv=d.invgdp
gen dreer=d.reer
gen dtot=d.exprind
gen dgfor=d.grochfor
gen dgini=d.gini
gen dimp=d.imports
gen dmatr=d.matr_nt
gen dserv=d.servicegdp

gen Years = _n-1 - 15 if _n <= 36
gen zero = 0 if _n <= 36

scalar sig = 0.1
	
generate blow =.
generate selow =.

generate bhigh =.
generate sehigh =.

sum manexp, d
local lowman=r(p10)
local highman=r(p90)

sum xvar, d
local sdta=r(sd)

forvalues nvar = 1/15 {
reghdfe y`nvar' l(1/8).g xvar lavman intman d.grofor l(1/4).dgini l(1/4).dimp l(1/4).dpolity  l(1/4).dreer l(1/4).dmatr l(1/4).dsch l(1/4).dpop l(1/4).dtrade l(1/4).dinv l(1/4).dtot l(1/4)dserv, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

replace blow  = 0 if _n == 16
replace selow = 0 if _n == 16

replace bhigh  = 0 if _n == 16
replace sehigh = 0 if _n == 16

forvalues nvar = 17/36 {
reghdfe y`nvar' l(1/8).g xvar lavman intman d.grofor l(1/4).dgini l(1/4).dimp l(1/4).dpolity  l(1/4).dreer l(1/4).dmatr l(1/4).dsch l(1/4).dpop l(1/4).dtrade l(1/4).dinv l(1/4).dtot l(1/4)dserv, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

	gen uplow = blow + invnormal(1-sig/2)*selow if _n <= 36
	gen dnlow = blow - invnormal(1-sig/2)*selow if _n <= 36
	
	gen uphigh = bhigh + invnormal(1-sig/2)*sehigh if _n <= 36
	gen dnhigh = bhigh - invnormal(1-sig/2)*sehigh if _n <= 36
	
	

twoway (line uphigh Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnhigh  Years,  lcolor(gs12) lpattern(dash)) ///
	(line bhigh Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "high_allcont.eps",   replace

	
twoway (line uplow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnlow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line blow Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "low_allcont.eps",   replace
	
	
keep Years blow selow bhigh sehigh 

foreach i in blow selow bhigh sehigh{
rename `i' `i'allcont
}
*

keep if Years>10 & Years<15
drop Years
mkmat blowallcont selowallcont bhighallcont sehighallcont, mat(matallcont)


	
* 8. Interactions with income and schooling

cd "/Users/mhoyoslopez/Dropbox/Doctorado/PhD Dissertation/Dissertation/Empirical - Tariffs and Growth/data/"
clear
use database
xtset cocode year, yearly

gen y1=l16.lgdp-l.lgdp
gen y2=l15.lgdp-l.lgdp
gen y3=l14.lgdp-l.lgdp
gen y4=l13.lgdp-l.lgdp
gen y5=l12.lgdp-l.lgdp
gen y6=l11.lgdp-l.lgdp
gen y7=l10.lgdp-l.lgdp
gen y8=l9.lgdp-l.lgdp
gen y9=l8.lgdp-l.lgdp
gen y10=l7.lgdp-l.lgdp
gen y11=l6.lgdp-l.lgdp
gen y12=l5.lgdp-l.lgdp
gen y13=l4.lgdp-l.lgdp
gen y14=l3.lgdp-l.lgdp
gen y15=l2.lgdp-l.lgdp

gen y16=l.lgdp-l.lgdp

gen y17=lgdp-l.lgdp

gen y18=f1.lgdp-l.lgdp
gen y19=f2.lgdp-l.lgdp
gen y20=f3.lgdp-l.lgdp
gen y21=f4.lgdp-l.lgdp
gen y22=f5.lgdp-l.lgdp
gen y23=f6.lgdp-l.lgdp
gen y24=f7.lgdp-l.lgdp
gen y25=f8.lgdp-l.lgdp
gen y26=f9.lgdp-l.lgdp
gen y27=f10.lgdp-l.lgdp
gen y28=f11.lgdp-l.lgdp
gen y29=f12.lgdp-l.lgdp
gen y30=f13.lgdp-l.lgdp
gen y31=f14.lgdp-l.lgdp
gen y32=f15.lgdp-l.lgdp
gen y33=f16.lgdp-l.lgdp
gen y34=f17.lgdp-l.lgdp
gen y35=f18.lgdp-l.lgdp
gen y36=f19.lgdp-l.lgdp

gen dpolity=d.polity
gen dsch=d.hc
gen dtrade=d.trade
replace pop=ln(pop)
gen dpop=d.pop
gen dinv=d.invgdp
gen dreer=d.reer
gen dtot=d.exprind
gen dgfor=d.grochfor
gen dgini=d.gini
gen dimp=d.imports
gen dmatr=d.matr_nt

gen Years = _n-1 - 15 if _n <= 36
gen zero = 0 if _n <= 36

scalar sig = 0.1
	
generate blow =.
generate selow =.

generate bhigh =.
generate sehigh =.

sum manexp, d
local lowman=r(p10)
local highman=r(p90)

sum xvar, d
local sdta=r(sd)

cap drop lavinc
gen lavinc=(l.lgdp+l2.lgdp+l3.lgdp+l4.lgdp+l5.lgdp)/5
replace lavinc=lavinc/100
cap drop intinit
gen intinit=xvar*lavinc

sum lgdp,d
local medinc=r(p50)/100

gen lavsch=(l.hc+l2.hc+l3.hc+l4.hc+l5.hc)/5
gen intsch=xvar*lavsch

sum lavsch,d
local medsch=r(p50)

forvalues nvar = 1/15 {
reghdfe y`nvar' l(1/8).g xvar lavman intman lavinc intinit, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman]+`medinc'*_b[intinit])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman]+`medinc'*_b[intinit])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

replace blow  = 0 if _n == 16
replace selow = 0 if _n == 16

replace bhigh  = 0 if _n == 16
replace sehigh = 0 if _n == 16

forvalues nvar = 17/36 {
reghdfe y`nvar' l(1/8).g xvar lavman intman lavinc intinit, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman]+`medinc'*_b[intinit])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman]+`medinc'*_b[intinit])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

	gen uplow = blow + invnormal(1-sig/2)*selow if _n <= 36
	gen dnlow = blow - invnormal(1-sig/2)*selow if _n <= 36
	
	gen uphigh = bhigh + invnormal(1-sig/2)*sehigh if _n <= 36
	gen dnhigh = bhigh - invnormal(1-sig/2)*sehigh if _n <= 36
	
	

twoway (line uphigh Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnhigh  Years,  lcolor(gs12) lpattern(dash)) ///
	(line bhigh Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "high_interaction_1.eps",   replace

	
twoway (line uplow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnlow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line blow Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "low_interaction_1.eps",   replace
	
keep Years blow selow bhigh sehigh 

foreach i in blow selow bhigh sehigh{
rename `i' `i'inter1
}
*

keep if Years>10 & Years<15
drop Years
mkmat blowinter1 selowinter1 bhighinter1 sehighinter1, mat(matinter1)


*int schooling

cd "/Users/mhoyoslopez/Dropbox/Doctorado/PhD Dissertation/Dissertation/Empirical - Tariffs and Growth/data/"
clear
use database
xtset cocode year, yearly

gen y1=l16.lgdp-l.lgdp
gen y2=l15.lgdp-l.lgdp
gen y3=l14.lgdp-l.lgdp
gen y4=l13.lgdp-l.lgdp
gen y5=l12.lgdp-l.lgdp
gen y6=l11.lgdp-l.lgdp
gen y7=l10.lgdp-l.lgdp
gen y8=l9.lgdp-l.lgdp
gen y9=l8.lgdp-l.lgdp
gen y10=l7.lgdp-l.lgdp
gen y11=l6.lgdp-l.lgdp
gen y12=l5.lgdp-l.lgdp
gen y13=l4.lgdp-l.lgdp
gen y14=l3.lgdp-l.lgdp
gen y15=l2.lgdp-l.lgdp

gen y16=l.lgdp-l.lgdp

gen y17=lgdp-l.lgdp

gen y18=f1.lgdp-l.lgdp
gen y19=f2.lgdp-l.lgdp
gen y20=f3.lgdp-l.lgdp
gen y21=f4.lgdp-l.lgdp
gen y22=f5.lgdp-l.lgdp
gen y23=f6.lgdp-l.lgdp
gen y24=f7.lgdp-l.lgdp
gen y25=f8.lgdp-l.lgdp
gen y26=f9.lgdp-l.lgdp
gen y27=f10.lgdp-l.lgdp
gen y28=f11.lgdp-l.lgdp
gen y29=f12.lgdp-l.lgdp
gen y30=f13.lgdp-l.lgdp
gen y31=f14.lgdp-l.lgdp
gen y32=f15.lgdp-l.lgdp
gen y33=f16.lgdp-l.lgdp
gen y34=f17.lgdp-l.lgdp
gen y35=f18.lgdp-l.lgdp
gen y36=f19.lgdp-l.lgdp

gen dpolity=d.polity
gen dsch=d.hc
gen dtrade=d.trade
replace pop=ln(pop)
gen dpop=d.pop
gen dinv=d.invgdp
gen dreer=d.reer
gen dtot=d.exprind
gen dgfor=d.grochfor
gen dgini=d.gini
gen dimp=d.imports
gen dmatr=d.matr_nt

gen Years = _n-1 - 15 if _n <= 36
gen zero = 0 if _n <= 36

scalar sig = 0.1
	
generate blow =.
generate selow =.

generate bhigh =.
generate sehigh =.

sum manexp, d
local lowman=r(p10)
local highman=r(p90)

sum xvar, d
local sdta=r(sd)

cap drop lavinc
gen lavinc=(l.lgdp+l2.lgdp+l3.lgdp+l4.lgdp+l5.lgdp)/5
replace lavinc=lavinc/100
cap drop intinit
gen intinit=xvar*lavinc

sum lgdp,d
local medinc=r(p50)/100

gen lavsch=(l.hc+l2.hc+l3.hc+l4.hc+l5.hc)/5
gen intsch=xvar*lavsch

sum lavsch,d
local medsch=r(p50)

forvalues nvar = 1/15 {
reghdfe y`nvar' l(1/8).g xvar lavman intman lavsch intsch, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman]+`medsch'*_b[intsch])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman]+`medsch'*_b[intsch])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

replace blow  = 0 if _n == 16
replace selow = 0 if _n == 16

replace bhigh  = 0 if _n == 16
replace sehigh = 0 if _n == 16

forvalues nvar = 17/36 {
reghdfe y`nvar' l(1/8).g xvar lavman intman lavsch intsch, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman]+`medsch'*_b[intsch])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman]+`medsch'*_b[intsch])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

	gen uplow = blow + invnormal(1-sig/2)*selow if _n <= 36
	gen dnlow = blow - invnormal(1-sig/2)*selow if _n <= 36
	
	gen uphigh = bhigh + invnormal(1-sig/2)*sehigh if _n <= 36
	gen dnhigh = bhigh - invnormal(1-sig/2)*sehigh if _n <= 36
	
	

twoway (line uphigh Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnhigh  Years,  lcolor(gs12) lpattern(dash)) ///
	(line bhigh Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "high_interaction_2.eps",   replace

	
twoway (line uplow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnlow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line blow Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "low_interaction_2.eps",   replace
	
keep Years blow selow bhigh sehigh 

foreach i in blow selow bhigh sehigh{
rename `i' `i'inter2
}
*

keep if Years>10 & Years<15
drop Years
mkmat blowinter2 selowinter2 bhighinter2 sehighinter2, mat(matinter2)




	
* 9. Regional trends


cd "/Users/mhoyoslopez/Dropbox/Doctorado/PhD Dissertation/Dissertation/Empirical - Tariffs and Growth/data/"
clear
use database
xtset cocode year, yearly

gen y1=l16.lgdp-l.lgdp
gen y2=l15.lgdp-l.lgdp
gen y3=l14.lgdp-l.lgdp
gen y4=l13.lgdp-l.lgdp
gen y5=l12.lgdp-l.lgdp
gen y6=l11.lgdp-l.lgdp
gen y7=l10.lgdp-l.lgdp
gen y8=l9.lgdp-l.lgdp
gen y9=l8.lgdp-l.lgdp
gen y10=l7.lgdp-l.lgdp
gen y11=l6.lgdp-l.lgdp
gen y12=l5.lgdp-l.lgdp
gen y13=l4.lgdp-l.lgdp
gen y14=l3.lgdp-l.lgdp
gen y15=l2.lgdp-l.lgdp

gen y16=l.lgdp-l.lgdp

gen y17=lgdp-l.lgdp

gen y18=f1.lgdp-l.lgdp
gen y19=f2.lgdp-l.lgdp
gen y20=f3.lgdp-l.lgdp
gen y21=f4.lgdp-l.lgdp
gen y22=f5.lgdp-l.lgdp
gen y23=f6.lgdp-l.lgdp
gen y24=f7.lgdp-l.lgdp
gen y25=f8.lgdp-l.lgdp
gen y26=f9.lgdp-l.lgdp
gen y27=f10.lgdp-l.lgdp
gen y28=f11.lgdp-l.lgdp
gen y29=f12.lgdp-l.lgdp
gen y30=f13.lgdp-l.lgdp
gen y31=f14.lgdp-l.lgdp
gen y32=f15.lgdp-l.lgdp
gen y33=f16.lgdp-l.lgdp
gen y34=f17.lgdp-l.lgdp
gen y35=f18.lgdp-l.lgdp
gen y36=f19.lgdp-l.lgdp

gen dpolity=d.polity
gen dsch=d.hc
gen dtrade=d.trade
replace pop=ln(pop)
gen dpop=d.pop
gen dinv=d.invgdp
gen dreer=d.reer
gen dtot=d.exprind
gen dgfor=d.grochfor
gen dgini=d.gini
gen dimp=d.imports
gen dmatr=d.matr_nt

gen Years = _n-1 - 15 if _n <= 36
gen zero = 0 if _n <= 36

scalar sig = 0.1
	
generate blow =.
generate selow =.

generate bhigh =.
generate sehigh =.

sum manexp, d
local lowman=r(p10)
local highman=r(p90)

sum xvar, d
local sdta=r(sd)

forvalues nvar = 1/15 {
reghdfe y`nvar' l(1/8).g xvar lavman intman, absorb(rryy year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

replace blow  = 0 if _n == 16
replace selow = 0 if _n == 16

replace bhigh  = 0 if _n == 16
replace sehigh = 0 if _n == 16

forvalues nvar = 17/36 {
reghdfe y`nvar' l(1/8).g xvar lavman intman, absorb(rryy year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

	gen uplow = blow + invnormal(1-sig/2)*selow if _n <= 36
	gen dnlow = blow - invnormal(1-sig/2)*selow if _n <= 36
	
	gen uphigh = bhigh + invnormal(1-sig/2)*sehigh if _n <= 36
	gen dnhigh = bhigh - invnormal(1-sig/2)*sehigh if _n <= 36
	
	

twoway (line uphigh Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnhigh  Years,  lcolor(gs12) lpattern(dash)) ///
	(line bhigh Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "high_rryy.eps",   replace

	
twoway (line uplow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnlow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line blow Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "low_rryy.eps",   replace
	
	
keep Years blow selow bhigh sehigh 

foreach i in blow selow bhigh sehigh{
rename `i' `i'regtr
}
*

keep if Years>10 & Years<15
drop Years
mkmat blowregtr selowregtr bhighregtr sehighregtr, mat(matregtr)


* 10. Income groups trends


cd "/Users/mhoyoslopez/Dropbox/Doctorado/PhD Dissertation/Dissertation/Empirical - Tariffs and Growth/data/"
clear
use database
xtset cocode year, yearly

gen y1=l16.lgdp-l.lgdp
gen y2=l15.lgdp-l.lgdp
gen y3=l14.lgdp-l.lgdp
gen y4=l13.lgdp-l.lgdp
gen y5=l12.lgdp-l.lgdp
gen y6=l11.lgdp-l.lgdp
gen y7=l10.lgdp-l.lgdp
gen y8=l9.lgdp-l.lgdp
gen y9=l8.lgdp-l.lgdp
gen y10=l7.lgdp-l.lgdp
gen y11=l6.lgdp-l.lgdp
gen y12=l5.lgdp-l.lgdp
gen y13=l4.lgdp-l.lgdp
gen y14=l3.lgdp-l.lgdp
gen y15=l2.lgdp-l.lgdp

gen y16=l.lgdp-l.lgdp

gen y17=lgdp-l.lgdp

gen y18=f1.lgdp-l.lgdp
gen y19=f2.lgdp-l.lgdp
gen y20=f3.lgdp-l.lgdp
gen y21=f4.lgdp-l.lgdp
gen y22=f5.lgdp-l.lgdp
gen y23=f6.lgdp-l.lgdp
gen y24=f7.lgdp-l.lgdp
gen y25=f8.lgdp-l.lgdp
gen y26=f9.lgdp-l.lgdp
gen y27=f10.lgdp-l.lgdp
gen y28=f11.lgdp-l.lgdp
gen y29=f12.lgdp-l.lgdp
gen y30=f13.lgdp-l.lgdp
gen y31=f14.lgdp-l.lgdp
gen y32=f15.lgdp-l.lgdp
gen y33=f16.lgdp-l.lgdp
gen y34=f17.lgdp-l.lgdp
gen y35=f18.lgdp-l.lgdp
gen y36=f19.lgdp-l.lgdp

gen dpolity=d.polity
gen dsch=d.hc
gen dtrade=d.trade
replace pop=ln(pop)
gen dpop=d.pop
gen dinv=d.invgdp
gen dreer=d.reer
gen dtot=d.exprind
gen dgfor=d.grochfor
gen dgini=d.gini
gen dimp=d.imports
gen dmatr=d.matr_nt

gen Years = _n-1 - 15 if _n <= 36
gen zero = 0 if _n <= 36

scalar sig = 0.1
	
generate blow =.
generate selow =.

generate bhigh =.
generate sehigh =.

sum manexp, d
local lowman=r(p10)
local highman=r(p90)

sum xvar, d
local sdta=r(sd)

forvalues nvar = 1/15 {
reghdfe y`nvar' l(1/8).g xvar lavman intman, absorb(interfull year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

replace blow  = 0 if _n == 16
replace selow = 0 if _n == 16

replace bhigh  = 0 if _n == 16
replace sehigh = 0 if _n == 16

forvalues nvar = 17/36 {
reghdfe y`nvar' l(1/8).g xvar lavman intman, absorb(interfull year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

	gen uplow = blow + invnormal(1-sig/2)*selow if _n <= 36
	gen dnlow = blow - invnormal(1-sig/2)*selow if _n <= 36
	
	gen uphigh = bhigh + invnormal(1-sig/2)*sehigh if _n <= 36
	gen dnhigh = bhigh - invnormal(1-sig/2)*sehigh if _n <= 36
	
	

twoway (line uphigh Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnhigh  Years,  lcolor(gs12) lpattern(dash)) ///
	(line bhigh Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "high_interfull.eps",   replace

	
twoway (line uplow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnlow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line blow Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "low_interfull.eps",   replace
	
keep Years blow selow bhigh sehigh 

foreach i in blow selow bhigh sehigh{
rename `i' `i'inctr
}
*

keep if Years>10 & Years<15
drop Years
mkmat blowinctr selowinctr bhighinctr sehighinctr, mat(matinctr)


* 11. Interactions of manufacturing with past growth and time fixed effects

cd "/Users/mhoyoslopez/Dropbox/Doctorado/PhD Dissertation/Dissertation/Empirical - Tariffs and Growth/data/"
set more off
clear
use database
xtset cocode year, yearly

gen y1=l16.lgdp-l.lgdp
gen y2=l15.lgdp-l.lgdp
gen y3=l14.lgdp-l.lgdp
gen y4=l13.lgdp-l.lgdp
gen y5=l12.lgdp-l.lgdp
gen y6=l11.lgdp-l.lgdp
gen y7=l10.lgdp-l.lgdp
gen y8=l9.lgdp-l.lgdp
gen y9=l8.lgdp-l.lgdp
gen y10=l7.lgdp-l.lgdp
gen y11=l6.lgdp-l.lgdp
gen y12=l5.lgdp-l.lgdp
gen y13=l4.lgdp-l.lgdp
gen y14=l3.lgdp-l.lgdp
gen y15=l2.lgdp-l.lgdp

gen y16=l.lgdp-l.lgdp

gen y17=lgdp-l.lgdp

gen y18=f1.lgdp-l.lgdp
gen y19=f2.lgdp-l.lgdp
gen y20=f3.lgdp-l.lgdp
gen y21=f4.lgdp-l.lgdp
gen y22=f5.lgdp-l.lgdp
gen y23=f6.lgdp-l.lgdp
gen y24=f7.lgdp-l.lgdp
gen y25=f8.lgdp-l.lgdp
gen y26=f9.lgdp-l.lgdp
gen y27=f10.lgdp-l.lgdp
gen y28=f11.lgdp-l.lgdp
gen y29=f12.lgdp-l.lgdp
gen y30=f13.lgdp-l.lgdp
gen y31=f14.lgdp-l.lgdp
gen y32=f15.lgdp-l.lgdp
gen y33=f16.lgdp-l.lgdp
gen y34=f17.lgdp-l.lgdp
gen y35=f18.lgdp-l.lgdp
gen y36=f19.lgdp-l.lgdp

gen Years = _n-1 - 15 if _n <= 36
gen zero = 0 if _n <= 36

scalar sig = 0.1
	
generate blow =.
generate selow =.

generate bhigh =.
generate sehigh =.

sum manexp, d
local lowman=r(p10)
local highman=r(p90)

sum xvar, d
local sdta=r(sd)

forval i=1/8{
	gen intgm`i'=l`i'.g*lavman
} 

forvalues nvar = 1/15 {
reghdfe y`nvar' l(1/8).g xvar lavman intman intgm*, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

replace blow  = 0 if _n == 16
replace selow = 0 if _n == 16

replace bhigh  = 0 if _n == 16
replace sehigh = 0 if _n == 16

forvalues nvar = 17/36 {
reghdfe y`nvar' l(1/8).g xvar lavman intman intgm*, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

	gen uplow = blow + invnormal(1-sig/2)*selow if _n <= 36
	gen dnlow = blow - invnormal(1-sig/2)*selow if _n <= 36
	
	gen uphigh = bhigh + invnormal(1-sig/2)*sehigh if _n <= 36
	gen dnhigh = bhigh - invnormal(1-sig/2)*sehigh if _n <= 36
	
	
twoway (line uplow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnlow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line blow Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "low_growthint.eps",   replace
	
twoway (line uphigh Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnhigh  Years,  lcolor(gs12) lpattern(dash)) ///
	(line bhigh Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "high_growthint.eps",   replace
	
keep Years blow selow bhigh sehigh 

foreach i in blow selow bhigh sehigh{
rename `i' `i'intpast
}
*

keep if Years>10 & Years<15
drop Years
mkmat blowintpast selowintpast bhighintpast sehighintpast, mat(matintpast)
	
	
cd "/Users/mhoyoslopez/Dropbox/Doctorado/PhD Dissertation/Dissertation/Empirical - Tariffs and Growth/data/"
set more off
clear
use database
xtset cocode year, yearly

gen y1=l16.lgdp-l.lgdp
gen y2=l15.lgdp-l.lgdp
gen y3=l14.lgdp-l.lgdp
gen y4=l13.lgdp-l.lgdp
gen y5=l12.lgdp-l.lgdp
gen y6=l11.lgdp-l.lgdp
gen y7=l10.lgdp-l.lgdp
gen y8=l9.lgdp-l.lgdp
gen y9=l8.lgdp-l.lgdp
gen y10=l7.lgdp-l.lgdp
gen y11=l6.lgdp-l.lgdp
gen y12=l5.lgdp-l.lgdp
gen y13=l4.lgdp-l.lgdp
gen y14=l3.lgdp-l.lgdp
gen y15=l2.lgdp-l.lgdp

gen y16=l.lgdp-l.lgdp

gen y17=lgdp-l.lgdp

gen y18=f1.lgdp-l.lgdp
gen y19=f2.lgdp-l.lgdp
gen y20=f3.lgdp-l.lgdp
gen y21=f4.lgdp-l.lgdp
gen y22=f5.lgdp-l.lgdp
gen y23=f6.lgdp-l.lgdp
gen y24=f7.lgdp-l.lgdp
gen y25=f8.lgdp-l.lgdp
gen y26=f9.lgdp-l.lgdp
gen y27=f10.lgdp-l.lgdp
gen y28=f11.lgdp-l.lgdp
gen y29=f12.lgdp-l.lgdp
gen y30=f13.lgdp-l.lgdp
gen y31=f14.lgdp-l.lgdp
gen y32=f15.lgdp-l.lgdp
gen y33=f16.lgdp-l.lgdp
gen y34=f17.lgdp-l.lgdp
gen y35=f18.lgdp-l.lgdp
gen y36=f19.lgdp-l.lgdp

gen Years = _n-1 - 15 if _n <= 36
gen zero = 0 if _n <= 36

scalar sig = 0.1
	
generate blow =.
generate selow =.

generate bhigh =.
generate sehigh =.

sum manexp, d
local lowman=r(p10)
local highman=r(p90)

sum xvar, d
local sdta=r(sd)

forval i=1/60{
	gen intym`i'=yy`i'*lavman
}

forvalues nvar = 1/15 {
reghdfe y`nvar' l(1/8).g xvar lavman intman intym*, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

replace blow  = 0 if _n == 16
replace selow = 0 if _n == 16

replace bhigh  = 0 if _n == 16
replace sehigh = 0 if _n == 16

forvalues nvar = 17/36 {
reghdfe y`nvar' l(1/8).g xvar lavman intman intym*, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

	gen uplow = blow + invnormal(1-sig/2)*selow if _n <= 36
	gen dnlow = blow - invnormal(1-sig/2)*selow if _n <= 36
	
	gen uphigh = bhigh + invnormal(1-sig/2)*sehigh if _n <= 36
	gen dnhigh = bhigh - invnormal(1-sig/2)*sehigh if _n <= 36
	
	
twoway (line uplow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnlow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line blow Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "low_yearint.eps",   replace
	
twoway (line uphigh Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnhigh  Years,  lcolor(gs12) lpattern(dash)) ///
	(line bhigh Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "high_yearint.eps",   replace

	
keep Years blow selow bhigh sehigh 

foreach i in blow selow bhigh sehigh{
rename `i' `i'inttime
}
*

keep if Years>10 & Years<15
drop Years
mkmat blowinttime selowinttime bhighinttime sehighinttime, mat(matinttime)
	


*Summary graph

clear
foreach i in allcont inter1 inter2 regtr inctr intpast inttime {
	clear
	svmat mat`i'
	gen var="`i'"
	gen Years = _n+10
	rename mat`i'1 blow
	rename mat`i'2 selow
	rename mat`i'3 bhigh
	rename mat`i'4 sehigh
	save `i'.dta, replace
	
}
*

use allcont.dta, clear
foreach i in inter1 inter2 regtr inctr intpast inttime{
	append using `i'.dta
	erase `i'.dta
}
*

erase allcont.dta

gen varcode=1 if var=="allcont"         
replace varcode=2 if var=="inter1"
replace varcode=3 if var=="inter2"
replace varcode=4 if var=="regtr"
replace varcode=5 if var=="inctr"
replace varcode=6 if var=="intpast"
replace varcode=7 if var=="inttime"

sort varcode Years

by varcode: gen betalow=sum(blow)/4
by varcode: gen sdlow=sqrt(sum((selow^2)/4))
by varcode: gen betahigh=sum(bhigh)/4
by varcode: gen sdhigh=sqrt(sum((sehigh^2)/4))

keep if Years==14
drop Years blow selow bhigh sehigh

scalar sig=0.1

gen uplow = betalow + invnormal(1-sig/2)*sdlow if _n <= 36
gen dnlow = betalow - invnormal(1-sig/2)*sdlow if _n <= 36
	
gen uphigh = betahigh + invnormal(1-sig/2)*sdhigh if _n <= 36
gen dnhigh = betahigh - invnormal(1-sig/2)*sdhigh if _n <= 36

gen zero = 0 

twoway (rcap uplow dnlow varcode,  lcolor(gs6)) /// 
	(rcap uphigh dnhigh varcode,  lcolor(gs12)) /// 
	(scatter betahigh varcode,  mcolor(gs12) ) ///
	(line zero varcode, lcolor(black)) ///
	(scatter betalow varcode,  mcolor(gs6) xlabel(1(1)7) ), ///
	ytitle("Change in GDP per capita log points", size(medsmall)) xtitle("Robustness exercise Nº", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(order(5 "Nonmanufacturer" 3 "Manufacturer") position(6) rows(1))
	graph export "robust.eps",   replace


	
********************************************************************************	
****** Mechanisms ******
********************************************************************************
	
	
cd "/Users/mhoyoslopez/Dropbox/Doctorado/PhD Dissertation/Dissertation/Empirical - Tariffs and Growth/data/"
clear all
use database
xtset cocode year, yearly

* Labor productivity

gen labprod=100*ln(rgdpna/emp)

replace lgdp=labprod

gen y1=l16.lgdp-l.lgdp
gen y2=l15.lgdp-l.lgdp
gen y3=l14.lgdp-l.lgdp
gen y4=l13.lgdp-l.lgdp
gen y5=l12.lgdp-l.lgdp
gen y6=l11.lgdp-l.lgdp
gen y7=l10.lgdp-l.lgdp
gen y8=l9.lgdp-l.lgdp
gen y9=l8.lgdp-l.lgdp
gen y10=l7.lgdp-l.lgdp
gen y11=l6.lgdp-l.lgdp
gen y12=l5.lgdp-l.lgdp
gen y13=l4.lgdp-l.lgdp
gen y14=l3.lgdp-l.lgdp
gen y15=l2.lgdp-l.lgdp

gen y16=l.lgdp-l.lgdp

gen y17=lgdp-l.lgdp

gen y18=f1.lgdp-l.lgdp
gen y19=f2.lgdp-l.lgdp
gen y20=f3.lgdp-l.lgdp
gen y21=f4.lgdp-l.lgdp
gen y22=f5.lgdp-l.lgdp
gen y23=f6.lgdp-l.lgdp
gen y24=f7.lgdp-l.lgdp
gen y25=f8.lgdp-l.lgdp
gen y26=f9.lgdp-l.lgdp
gen y27=f10.lgdp-l.lgdp
gen y28=f11.lgdp-l.lgdp
gen y29=f12.lgdp-l.lgdp
gen y30=f13.lgdp-l.lgdp
gen y31=f14.lgdp-l.lgdp
gen y32=f15.lgdp-l.lgdp
gen y33=f16.lgdp-l.lgdp
gen y34=f17.lgdp-l.lgdp
gen y35=f18.lgdp-l.lgdp
gen y36=f19.lgdp-l.lgdp

gen delta=lgdp-l.lgdp

gen dpolity=d.polity
gen dsch=d.hc
gen dtrade=d.trade
replace pop=ln(pop)
gen dpop=d.pop
gen dinv=d.invgdp
gen dreer=d.reer
gen dtot=d.exprind
gen dgfor=d.grochfor
gen dgini=d.gini
gen dimp=d.imports
gen dmatr=d.matr_nt

gen Years = _n-1 - 15 if _n <= 36
gen zero = 0 if _n <= 36

scalar sig = 0.1
	
generate blow =.
generate selow =.

generate bhigh =.
generate sehigh =.

sum manexp, d
local lowman=r(p10)
local highman=r(p90)

sum xvar, d
local sdta=r(sd)

forvalues nvar = 1/15 {
reghdfe y`nvar' l(1/8).delta l(1/8).g xvar lavman intman, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

replace blow  = 0 if _n == 16
replace selow = 0 if _n == 16

replace bhigh  = 0 if _n == 16
replace sehigh = 0 if _n == 16

forvalues nvar = 17/36 {
reghdfe y`nvar' l(1/8).delta l(1/8).g xvar lavman intman, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

	gen uplow = blow + invnormal(1-sig/2)*selow if _n <= 36
	gen dnlow = blow - invnormal(1-sig/2)*selow if _n <= 36
	
	gen uphigh = bhigh + invnormal(1-sig/2)*sehigh if _n <= 36
	gen dnhigh = bhigh - invnormal(1-sig/2)*sehigh if _n <= 36
	
	
twoway (line uplow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnlow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line blow Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in labor productivity log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "low_mech_labprod.eps",   replace
	
twoway (line uphigh Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnhigh  Years,  lcolor(gs12) lpattern(dash)) ///
	(line bhigh Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in labor productivity log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "high_mech_labprod.eps",   replace

	
* Capital stocks

use database, clear
xtset cocode year, yearly

gen labprod=100*ln(rgdpna/emp)
gen capst=100*ln(rnna)

replace lgdp=capst

gen y1=l16.lgdp-l.lgdp
gen y2=l15.lgdp-l.lgdp
gen y3=l14.lgdp-l.lgdp
gen y4=l13.lgdp-l.lgdp
gen y5=l12.lgdp-l.lgdp
gen y6=l11.lgdp-l.lgdp
gen y7=l10.lgdp-l.lgdp
gen y8=l9.lgdp-l.lgdp
gen y9=l8.lgdp-l.lgdp
gen y10=l7.lgdp-l.lgdp
gen y11=l6.lgdp-l.lgdp
gen y12=l5.lgdp-l.lgdp
gen y13=l4.lgdp-l.lgdp
gen y14=l3.lgdp-l.lgdp
gen y15=l2.lgdp-l.lgdp

gen y16=l.lgdp-l.lgdp

gen y17=lgdp-l.lgdp

gen y18=f1.lgdp-l.lgdp
gen y19=f2.lgdp-l.lgdp
gen y20=f3.lgdp-l.lgdp
gen y21=f4.lgdp-l.lgdp
gen y22=f5.lgdp-l.lgdp
gen y23=f6.lgdp-l.lgdp
gen y24=f7.lgdp-l.lgdp
gen y25=f8.lgdp-l.lgdp
gen y26=f9.lgdp-l.lgdp
gen y27=f10.lgdp-l.lgdp
gen y28=f11.lgdp-l.lgdp
gen y29=f12.lgdp-l.lgdp
gen y30=f13.lgdp-l.lgdp
gen y31=f14.lgdp-l.lgdp
gen y32=f15.lgdp-l.lgdp
gen y33=f16.lgdp-l.lgdp
gen y34=f17.lgdp-l.lgdp
gen y35=f18.lgdp-l.lgdp
gen y36=f19.lgdp-l.lgdp

gen delta=lgdp-l.lgdp

gen dpolity=d.polity
gen dsch=d.hc
gen dtrade=d.trade
replace pop=ln(pop)
gen dpop=d.pop
gen dinv=d.invgdp
gen dreer=d.reer
gen dtot=d.exprind
gen dgfor=d.grochfor
gen dgini=d.gini
gen dimp=d.imports
gen dmatr=d.matr_nt

gen Years = _n-1 - 15 if _n <= 36
gen zero = 0 if _n <= 36

scalar sig = 0.1
	
generate blow =.
generate selow =.

generate bhigh =.
generate sehigh =.

sum manexp, d
local lowman=r(p10)
local highman=r(p90)

sum xvar, d
local sdta=r(sd)

forvalues nvar = 1/15 {
reghdfe y`nvar' l(1/8).delta l(1/8).g xvar lavman intman, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

replace blow  = 0 if _n == 16
replace selow = 0 if _n == 16

replace bhigh  = 0 if _n == 16
replace sehigh = 0 if _n == 16

forvalues nvar = 17/36 {
reghdfe y`nvar' l(1/8).delta l(1/8).g xvar lavman intman, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

	gen uplow = blow + invnormal(1-sig/2)*selow if _n <= 36
	gen dnlow = blow - invnormal(1-sig/2)*selow if _n <= 36
	
	gen uphigh = bhigh + invnormal(1-sig/2)*sehigh if _n <= 36
	gen dnhigh = bhigh - invnormal(1-sig/2)*sehigh if _n <= 36
	
	
twoway (line uplow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnlow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line blow Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in capital stock log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "low_mech_capst.eps",   replace
	
twoway (line uphigh Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnhigh  Years,  lcolor(gs12) lpattern(dash)) ///
	(line bhigh Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in capital stock log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "high_mech_capst.eps",   replace

	
* Man. share of employment


use database, clear
xtset cocode year, yearly

replace lgdp=manshare

gen y1=l16.lgdp-l.lgdp
gen y2=l15.lgdp-l.lgdp
gen y3=l14.lgdp-l.lgdp
gen y4=l13.lgdp-l.lgdp
gen y5=l12.lgdp-l.lgdp
gen y6=l11.lgdp-l.lgdp
gen y7=l10.lgdp-l.lgdp
gen y8=l9.lgdp-l.lgdp
gen y9=l8.lgdp-l.lgdp
gen y10=l7.lgdp-l.lgdp
gen y11=l6.lgdp-l.lgdp
gen y12=l5.lgdp-l.lgdp
gen y13=l4.lgdp-l.lgdp
gen y14=l3.lgdp-l.lgdp
gen y15=l2.lgdp-l.lgdp

gen y16=l.lgdp-l.lgdp

gen y17=lgdp-l.lgdp

gen y18=f1.lgdp-l.lgdp
gen y19=f2.lgdp-l.lgdp
gen y20=f3.lgdp-l.lgdp
gen y21=f4.lgdp-l.lgdp
gen y22=f5.lgdp-l.lgdp
gen y23=f6.lgdp-l.lgdp
gen y24=f7.lgdp-l.lgdp
gen y25=f8.lgdp-l.lgdp
gen y26=f9.lgdp-l.lgdp
gen y27=f10.lgdp-l.lgdp
gen y28=f11.lgdp-l.lgdp
gen y29=f12.lgdp-l.lgdp
gen y30=f13.lgdp-l.lgdp
gen y31=f14.lgdp-l.lgdp
gen y32=f15.lgdp-l.lgdp
gen y33=f16.lgdp-l.lgdp
gen y34=f17.lgdp-l.lgdp
gen y35=f18.lgdp-l.lgdp
gen y36=f19.lgdp-l.lgdp

gen delta=lgdp-l.lgdp

gen dpolity=d.polity
gen dsch=d.hc
gen dtrade=d.trade
replace pop=ln(pop)
gen dpop=d.pop
gen dinv=d.invgdp
gen dreer=d.reer
gen dtot=d.exprind
gen dgfor=d.grochfor
gen dgini=d.gini
gen dimp=d.imports
gen dmatr=d.matr_nt

gen Years = _n-1 - 15 if _n <= 36
gen zero = 0 if _n <= 36

scalar sig = 0.1
	
generate blow =.
generate selow =.

generate bhigh =.
generate sehigh =.

sum manexp, d
local lowman=r(p10)
local highman=r(p90)

sum xvar, d
local sdta=r(sd)

forvalues nvar = 1/15 {
reghdfe y`nvar' l(1/8).delta l(1/8).g xvar lavman intman , absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

replace blow  = 0 if _n == 16
replace selow = 0 if _n == 16

replace bhigh  = 0 if _n == 16
replace sehigh = 0 if _n == 16

forvalues nvar = 17/36 {
reghdfe y`nvar' l(1/8).delta l(1/8).g xvar lavman intman , absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

	gen uplow = blow + invnormal(1-sig/2)*selow if _n <= 36
	gen dnlow = blow - invnormal(1-sig/2)*selow if _n <= 36
	
	gen uphigh = bhigh + invnormal(1-sig/2)*sehigh if _n <= 36
	gen dnhigh = bhigh - invnormal(1-sig/2)*sehigh if _n <= 36
	
	
twoway (line uplow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnlow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line blow Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in manufacturing share percentage points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "low_mech_manshare.eps",   replace
	
twoway (line uphigh Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnhigh  Years,  lcolor(gs12) lpattern(dash)) ///
	(line bhigh Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in manufacturing share percentage points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "high_mech_manshare.eps",   replace

	
* Imports


use database, clear
xtset cocode year, yearly


replace lgdp=imports

gen y1=l16.lgdp-l.lgdp
gen y2=l15.lgdp-l.lgdp
gen y3=l14.lgdp-l.lgdp
gen y4=l13.lgdp-l.lgdp
gen y5=l12.lgdp-l.lgdp
gen y6=l11.lgdp-l.lgdp
gen y7=l10.lgdp-l.lgdp
gen y8=l9.lgdp-l.lgdp
gen y9=l8.lgdp-l.lgdp
gen y10=l7.lgdp-l.lgdp
gen y11=l6.lgdp-l.lgdp
gen y12=l5.lgdp-l.lgdp
gen y13=l4.lgdp-l.lgdp
gen y14=l3.lgdp-l.lgdp
gen y15=l2.lgdp-l.lgdp

gen y16=l.lgdp-l.lgdp

gen y17=lgdp-l.lgdp

gen y18=f1.lgdp-l.lgdp
gen y19=f2.lgdp-l.lgdp
gen y20=f3.lgdp-l.lgdp
gen y21=f4.lgdp-l.lgdp
gen y22=f5.lgdp-l.lgdp
gen y23=f6.lgdp-l.lgdp
gen y24=f7.lgdp-l.lgdp
gen y25=f8.lgdp-l.lgdp
gen y26=f9.lgdp-l.lgdp
gen y27=f10.lgdp-l.lgdp
gen y28=f11.lgdp-l.lgdp
gen y29=f12.lgdp-l.lgdp
gen y30=f13.lgdp-l.lgdp
gen y31=f14.lgdp-l.lgdp
gen y32=f15.lgdp-l.lgdp
gen y33=f16.lgdp-l.lgdp
gen y34=f17.lgdp-l.lgdp
gen y35=f18.lgdp-l.lgdp
gen y36=f19.lgdp-l.lgdp

gen delta=lgdp-l.lgdp

gen dpolity=d.polity
gen dsch=d.hc
gen dtrade=d.trade
replace pop=ln(pop)
gen dpop=d.pop
gen dinv=d.invgdp
gen dreer=d.reer
gen dtot=d.exprind
gen dgfor=d.grochfor
gen dgini=d.gini
gen dimp=d.imports
gen dmatr=d.matr_nt

gen Years = _n-1 - 15 if _n <= 36
gen zero = 0 if _n <= 36

scalar sig = 0.1
	
generate blow =.
generate selow =.

generate bhigh =.
generate sehigh =.

sum manexp, d
local lowman=r(p10)
local highman=r(p90)

sum xvar, d
local sdta=r(sd)

forvalues nvar = 1/15 {
reghdfe y`nvar' l(1/8).delta l(1/8).g xvar lavman intman, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

replace blow  = 0 if _n == 16
replace selow = 0 if _n == 16

replace bhigh  = 0 if _n == 16
replace sehigh = 0 if _n == 16

forvalues nvar = 17/36 {
reghdfe y`nvar' l(1/8).delta l(1/8).g xvar lavman intman, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

	gen uplow = blow + invnormal(1-sig/2)*selow if _n <= 36
	gen dnlow = blow - invnormal(1-sig/2)*selow if _n <= 36
	
	gen uphigh = bhigh + invnormal(1-sig/2)*sehigh if _n <= 36
	gen dnhigh = bhigh - invnormal(1-sig/2)*sehigh if _n <= 36
	
	
twoway (line uplow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnlow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line blow Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in imports log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "low_mech_imports.eps",   replace
	
twoway (line uphigh Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnhigh  Years,  lcolor(gs12) lpattern(dash)) ///
	(line bhigh Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in imports log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "high_mech_imports.eps",   replace

* TFP


use database, clear
xtset cocode year, yearly

replace rtfpna=ln(rtfpna)*100

replace lgdp=rtfpna

gen y1=l16.lgdp-l.lgdp
gen y2=l15.lgdp-l.lgdp
gen y3=l14.lgdp-l.lgdp
gen y4=l13.lgdp-l.lgdp
gen y5=l12.lgdp-l.lgdp
gen y6=l11.lgdp-l.lgdp
gen y7=l10.lgdp-l.lgdp
gen y8=l9.lgdp-l.lgdp
gen y9=l8.lgdp-l.lgdp
gen y10=l7.lgdp-l.lgdp
gen y11=l6.lgdp-l.lgdp
gen y12=l5.lgdp-l.lgdp
gen y13=l4.lgdp-l.lgdp
gen y14=l3.lgdp-l.lgdp
gen y15=l2.lgdp-l.lgdp

gen y16=l.lgdp-l.lgdp

gen y17=lgdp-l.lgdp

gen y18=f1.lgdp-l.lgdp
gen y19=f2.lgdp-l.lgdp
gen y20=f3.lgdp-l.lgdp
gen y21=f4.lgdp-l.lgdp
gen y22=f5.lgdp-l.lgdp
gen y23=f6.lgdp-l.lgdp
gen y24=f7.lgdp-l.lgdp
gen y25=f8.lgdp-l.lgdp
gen y26=f9.lgdp-l.lgdp
gen y27=f10.lgdp-l.lgdp
gen y28=f11.lgdp-l.lgdp
gen y29=f12.lgdp-l.lgdp
gen y30=f13.lgdp-l.lgdp
gen y31=f14.lgdp-l.lgdp
gen y32=f15.lgdp-l.lgdp
gen y33=f16.lgdp-l.lgdp
gen y34=f17.lgdp-l.lgdp
gen y35=f18.lgdp-l.lgdp
gen y36=f19.lgdp-l.lgdp

gen delta=lgdp-l.lgdp

gen dpolity=d.polity
gen dsch=d.hc
gen dtrade=d.trade
replace pop=ln(pop)
gen dpop=d.pop
gen dinv=d.invgdp
gen dreer=d.reer
gen dtot=d.exprind
gen dgfor=d.grochfor
gen dgini=d.gini
gen dimp=d.imports
gen dmatr=d.matr_nt

gen Years = _n-1 - 15 if _n <= 36
gen zero = 0 if _n <= 36

scalar sig = 0.1
	
generate blow =.
generate selow =.

generate bhigh =.
generate sehigh =.

sum manexp, d
local lowman=r(p10)
local highman=r(p90)

sum xvar, d
local sdta=r(sd)

forvalues nvar = 1/15 {
reghdfe y`nvar' l(1/8).delta l(1/8).g xvar lavman intman, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

replace blow  = 0 if _n == 16
replace selow = 0 if _n == 16

replace bhigh  = 0 if _n == 16
replace sehigh = 0 if _n == 16

forvalues nvar = 17/36 {
reghdfe y`nvar' l(1/8).delta l(1/8).g xvar lavman intman, absorb(year) cluster(cocode)
nlcom (Delta_tariffs: _b[xvar]) (lavman: _b[lavman]) (intman:_b[intman]) (low:-1*`sdta'*(_b[xvar]+`lowman'*_b[intman])) (high:-1*`sdta'*(_b[xvar]+`highman'*_b[intman])), post

replace blow  = _b[low] if _n == `nvar'
replace selow = _se[low] if _n == `nvar'

replace bhigh  = _b[high] if _n == `nvar'
replace sehigh = _se[high] if _n == `nvar'
}

	gen uplow = blow + invnormal(1-sig/2)*selow if _n <= 36
	gen dnlow = blow - invnormal(1-sig/2)*selow if _n <= 36
	
	gen uphigh = bhigh + invnormal(1-sig/2)*sehigh if _n <= 36
	gen dnhigh = bhigh - invnormal(1-sig/2)*sehigh if _n <= 36
	
	
twoway (line uplow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnlow  Years,  lcolor(gs12) lpattern(dash)) ///
	(line blow Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in TFP log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "low_mech_rtfpna.eps",   replace
	
twoway (line uphigh Years,  lcolor(gs12) lpattern(dash)) ///
	(line dnhigh  Years,  lcolor(gs12) lpattern(dash)) ///
	(line bhigh Years, lcolor(black) ///
	lpattern(solid) lwidth(thick)) /// 
	(line zero Years, lcolor(black) xlabel(-15(5)20) xline(0, lcolor(gs12))), ///
	ytitle("Change in TFP log points", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) legend(off) 
	graph export "high_mech_rtfpna.eps",   replace
*


